
class Statistics:

    def __init__(self, scaffoldInstance):
        self.scaffold = scaffoldInstance
        self.placement = {}
